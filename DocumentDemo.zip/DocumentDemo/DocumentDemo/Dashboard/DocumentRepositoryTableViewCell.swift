
//
//  DocumentRepositoryTableViewCell.swift
//  DocumentDemo
//
//  Created by Uddhav on 16/06/19.
//  Copyright © 2019 Uddhav. All rights reserved.
//

import UIKit

class DocumentRepositoryTableViewCell: UITableViewCell {

    @IBOutlet weak var documnetImage: UIImageView!
    @IBOutlet weak var documentNameLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
