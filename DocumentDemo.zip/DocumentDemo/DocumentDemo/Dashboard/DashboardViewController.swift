//
//  DashboardViewController.swift
//  DocumentDemo
//
//  Created by Uddhav on 16/06/19.
//  Copyright © 2019 Uddhav. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {

  //  let home = Storyboard.controller.sideView()
    
    @IBOutlet weak var menuBarButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
       
        if revealViewController() != nil {
            menuBarButton.target = revealViewController()
            menuBarButton.action = "revealToggle:"
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        //    self.animateTable()
        
     //   UINavigationBar.appearance().barTintColor = UIColor(red: 19.0/255.0, green: 74.0/255.0, blue: 153.0/255.0, alpha: 100.0/100.0)
//        //      UINavigationBar.appearance().barTintColor = UIColor.red
//        UINavigationBar.appearance().tintColor = .white
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        //back button Image and text
  //      self.navigationController?.navigationBar.topItem?.title = ""
        
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        //set center logo
        
        //        let logo = UIImage(named: "ic_edelweiss")
        //        let imageView = UIImageView(image:logo)
        //        self.navigationItem.titleView = imageView

        
//        //set left bar button item
//        let button1 = UIBarButtonItem(image: UIImage(named: "menuicon"), style: .plain, target: self, action: #selector(DashboardViewController.homeButton))
//        self.navigationItem.leftBarButtonItem = button1
        
    }
    @objc func homeButton(){
        print("button click")
        
//        UIView.animate(withDuration: 0.2) { () -> Void in
//            self.addChild(self.home)
//            self.view.addSubview(self.home.view)
//        }
        
       
    }
   
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//
//        weak var welf = self
//        UIView.animate(withDuration: 0.2) { ()->Void in
//
//            welf?.home.view.removeFromSuperview()
//        }
//    }
    
}

