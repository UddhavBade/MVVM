//
//  sideMenuTableViewCell.swift
//  QS TAXIAPP
//
//  Created by Uddhav on 25/10/18.
//  Copyright © 2018 Uddhav. All rights reserved.
//

import UIKit

class sideMenuTableViewCell: UITableViewCell {

    @IBOutlet var imgSideOption: UIImageView!
    
    @IBOutlet var lblSideOption: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

