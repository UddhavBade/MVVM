//
//  SideMenuVC.swift
//  QS TAXIAPP
//
//  Created by Uddhav on 25/10/18.
//  Copyright © 2018 Uddhav. All rights reserved.
//

import UIKit

class SideMenuVC: UIViewController {

    @IBOutlet var sideMenuTableView: UITableView!
    
    private var arrSideOption = ["Home","Profile","Documents","Logout"]
    private var arrImgOption = ["home","profilem","document","logout"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

     }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
}
//TODO: TABLEVIEW METHOD
extension SideMenuVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         let noOfRow = arrSideOption.count
            print(noOfRow)
            return noOfRow
        
     }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sideMenuTableViewCell", for: indexPath) as! sideMenuTableViewCell
        cell.lblSideOption.text = arrSideOption[indexPath.row]
        
        let imageName = UIImage(named:  arrImgOption[indexPath.row])
        cell.imgSideOption?.image = imageName
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0{
           
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "home")
            
            let segue = SWRevealViewControllerSeguePushController(identifier: "Home", source: self, destination: vc)
            segue.perform()
        }
        else if indexPath.row == 1{
           
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Profile")
            
            let segue = SWRevealViewControllerSeguePushController(identifier: "Home", source: self, destination: vc)
            segue.perform()
        }
        else if indexPath.row == 2{
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Document")
            
            let segue = SWRevealViewControllerSeguePushController(identifier: "Home", source: self, destination: vc)
            segue.perform()
        }
        else if indexPath.row == 3{
           
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Login")
            
            let segue = SWRevealViewControllerSeguePushController(identifier: "Home", source: self, destination: vc)
            segue.perform()
        }
        
//        switch indexPath.row {
//        case 0:
//
//            self.performSegue(withIdentifier: "HomeSegue", sender: self)
//
////            let vc: DashboardViewController = self.storyboard?.instantiateViewController(withIdentifier: "DashboardViewController") as! DashboardViewController
////            self.navigationController?.pushViewController(vc, animated: true)
//
//        case 1:
//
//            self.performSegue(withIdentifier: "ProfileSegue", sender: self)
//
////            let vc: ProfileViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
////            self.navigationController?.pushViewController(vc, animated: true)
//
//        case 2:
//
//            self.performSegue(withIdentifier: "DocumentSegue", sender: self)
//
////            let vc: DocumnetRepositoryViewController = self.storyboard?.instantiateViewController(withIdentifier: "DocumnetRepositoryViewController") as! DocumnetRepositoryViewController
////            self.navigationController?.pushViewController(vc, animated: true)
//
//        default:
//
//            self.performSegue(withIdentifier: "LoginSegue", sender: self)
//
////            let vc: LoginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
////            self.navigationController?.pushViewController(vc, animated: true)
//        }
      }
    
}
