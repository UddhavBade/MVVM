//
//  ProfileViewController.swift
//  DocumentDemo
//
//  Created by Uddhav on 16/06/19.
//  Copyright © 2019 Uddhav. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!

    @IBOutlet weak var menuBarButton: UIBarButtonItem!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getUserInfo()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if revealViewController() != nil {
            menuBarButton.target = revealViewController()
            menuBarButton.action = "revealToggle:"
        }
    }
    fileprivate func getUserInfo(){
        
        self.nameLabel.text = "Name : \(UserDefaults.standard.string(forKey: "USER_NAME")!)"
        self.emailLabel.text = "Email : \(UserDefaults.standard.string(forKey: "USER_EMAIL")!)"
        self.mobileLabel.text = "Mobile : \(UserDefaults.standard.string(forKey: "USER_MOBILE")!)"
    }
    
}
