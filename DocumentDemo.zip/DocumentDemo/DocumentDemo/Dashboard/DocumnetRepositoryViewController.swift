
//
//  DocumnetRepositoryViewController.swift
//  DocumentDemo
//
//  Created by Uddhav on 16/06/19.
//  Copyright © 2019 Uddhav. All rights reserved.
//

import UIKit
import CoreData

class DocumnetRepositoryViewController: UIViewController {

    @IBOutlet weak var menuBarButton: UIBarButtonItem!
    
    @IBOutlet weak var documentTableView: UITableView!
    
  //  fileprivate var imageArray : [String] = []
    fileprivate var nameArray : [String] = []
    
    var imageArray : NSMutableArray = NSMutableArray()
    
    var imageURLArray : [NSURL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
//        UserDefaults.standard.set(email, forKey: "USER_EMAIL")
//        UserDefaults.standard.set(name, forKey: "USER_NAME")
//        UserDefaults.standard.set(mobile, forKey: "USER_MOBILE")
//        UserDefaults.standard.set(userType, forKey: "USER_TYPE")
        
        let userType = UserDefaults.standard.string(forKey: "USER_TYPE")
        
        if userType == "1"{
           self.getDocument()
        }
        else{
            self.getDocument2()
        }
        
        self.loadImagesFromAlbum(folderName: "/Create Folder/")
        
        print(loadImagesFromAlbum(folderName: "/Create Folder/"))
        
        self.imageArray.addObjects(from: loadImagesFromAlbum(folderName: "/Create Folder/"))
        
        
    }
   
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if revealViewController() != nil {
            menuBarButton.target = revealViewController()
            menuBarButton.action = "revealToggle:"
        }
    }
    
    func getDocument() {
        
        let userType = UserDefaults.standard.string(forKey: "USER_TYPE")
        let mobile = UserDefaults.standard.string(forKey: "USER_MOBILE")
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        var context = NSManagedObjectContext()
        if #available(iOS 10.0, *) {
            context =
                appDelegate.persistentContainer.viewContext
        } else {
            // Fallback on earlier versions
            
            context = appDelegate.managedObjectContext
        }
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Document")
        let result = try? context.fetch(request)
        
        
        for u: Document? in result as? [Document?] ?? [] {
            //            let subCode = u?.subBrokerCode
            //            NSLog("subCode =\(String(describing: subCode))");
            
           // if (u?.mobileNo == mobile) {
              //  let subCode = u?.subBrokerCode
              //  print("ProfileCode =\(subCode ?? "")")
                let imgStr = u?.imageString
                let mb = u?.mobileNo
                
               
                self.nameArray.append(imgStr!)
                
            //    print("imgStr = \(imgStr)")
                print("mobile = \(mb)")
//
//                let data = NSData(base64Encoded: imgStr!, options: NSData.Base64DecodingOptions(rawValue: 0))
//             print(data)
//              //  let data = Data(base64Encoded: imgStr ?? "", options: [])
//                if let aData = data {
//                    let img = UIImage(data: aData as Data)
//
//                    self.imageArray.append(img!)
//
//                }
            
//            let imgStr = u?.imageString

            let data = Data(base64Encoded: imgStr ?? "", options: [])
            if let aData = data {
                let img = UIImage(data: aData)
                
              //  self.imageArray.append(img!)
            }
          //  }
        }
        
        
        self.documentTableView.delegate = self
        self.documentTableView.dataSource = self
        
        DispatchQueue.main.async {
            self.documentTableView.reloadData()
            
            self.animateTable()
        }
        
    }

    func getDocument2() {
        
        let userType = UserDefaults.standard.string(forKey: "USER_TYPE")
        let mobile = UserDefaults.standard.string(forKey: "USER_MOBILE")
        
        guard let appDelegate =
            UIApplication.shared.delegate as? AppDelegate else {
                return
        }
        
        // 1
        var context = NSManagedObjectContext()
        if #available(iOS 10.0, *) {
            context =
                appDelegate.persistentContainer.viewContext
        } else {
            // Fallback on earlier versions
            
            context = appDelegate.managedObjectContext
        }
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Document")
        let result = try? context.fetch(request)
        
        
        for u: Document? in result as? [Document?] ?? [] {
            //            let subCode = u?.subBrokerCode
            //            NSLog("subCode =\(String(describing: subCode))");
            
            if (u?.mobileNo == mobile) {
                //  let subCode = u?.subBrokerCode
                //  print("ProfileCode =\(subCode ?? "")")
                let imgStr = u?.imageString
                let mb = u?.mobileNo
                
                
                self.nameArray.append(imgStr!)
                
             //   print("imgStr = \(imgStr)")
                print("mobile = \(mb)")
                
                let data = NSData(base64Encoded: imgStr!, options: NSData.Base64DecodingOptions(rawValue: 0))
             //   print(data)
                //  let data = Data(base64Encoded: imgStr ?? "", options: [])
                if let aData = data {
                    let img = UIImage(data: aData as Data)
                    
                  //  self.imageArray.append(img!)
                    
                }
            }
        }
        
        
        self.documentTableView.delegate = self
        self.documentTableView.dataSource = self
        
        DispatchQueue.main.async {
            self.documentTableView.reloadData()
            
            self.animateTable()
        }
        
    }
    
    //TableView animations
    func animateTable() {
        self.documentTableView.reloadData()
        
        let cells = self.documentTableView.visibleCells
        let tableHeight: CGFloat = self.documentTableView.bounds.size.height
        
        for i in cells {
            let cell: UITableViewCell = i as UITableViewCell
            cell.transform = CGAffineTransform(translationX: 0, y: tableHeight)
        }
        
        var index = 0
        
        for a in cells {
            let cell: UITableViewCell = a as UITableViewCell
            UIView.animate(withDuration: 2.5, delay: 0.05 * Double(index), usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .transitionFlipFromBottom, animations: {
                cell.transform = CGAffineTransform(translationX: 0, y: 0);
            }, completion: nil)
            
            index += 1
        }
        
    }
}

extension DocumnetRepositoryViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nameArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = documentTableView.dequeueReusableCell(withIdentifier: "DocumentRepositoryTableViewCell", for: indexPath) as! DocumentRepositoryTableViewCell
        cell.documentNameLabel.text = nameArray[indexPath.row] as! String
       
//    //   let imgStr = imageArray[indexPath.row]
//
//    //   cell.documnetImage.image = UIImage()
//
//        let imageName = UIImage(named:  imageArray[indexPath.row] as! String)
//     //   cell.documnetImage?.image = imageName
//
//
//        let imgStr = imageURLArray[indexPath.row]
    
        
        return cell
        
    }
    
 func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("You selected row #\(indexPath.row)!")
        
     //   let str = searchArray.object(at: indexPath.row) as? String
}
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let cell:DocumentRepositoryTableViewCell = (self.documentTableView.dequeueReusableCell(withIdentifier: "DocumentRepositoryTableViewCell") as! DocumentRepositoryTableViewCell?)!
        
        return cell.frame.size.height;
        // return 30
        
    }
    
   
    func loadImagesFromAlbum(folderName:String) -> [String]{
        
        let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let nsUserDomainMask    = FileManager.SearchPathDomainMask.userDomainMask
        let paths               = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
        var theItems = [String]()
        if let dirPath          = paths.first
        {
            let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(folderName)
            
            self.imageURLArray.append(imageURL as NSURL)
            
            do {
                theItems = try FileManager.default.contentsOfDirectory(atPath: imageURL.path)
                
              //  self.imageArray.append(theItems)
                
                return theItems
            } catch let error as NSError {
                print(error.localizedDescription)
                return theItems
            }
        }
        return theItems
    }
    
}
