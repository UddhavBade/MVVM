//
//  Validation.swift
//  Edelweiss Subbroker
//
//  Created by Amit Bachhawat on 9/1/18.
//  Copyright © 2018 Amit Bachhawat. All rights reserved.
//

import UIKit

class Validation: NSObject {
    
    /**
     The all coommon methods & function are avaliable here
     */
    // MARK : isValidEmail
    class public func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailStr)
    }
    
    // MARK : isValidPhone
    class public func isValidPhone(phoneStr: String) -> Bool {
        let PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: phoneStr)
        return result
    }
    
    class public func isValidPassword(testStr:String?) -> Bool {
        guard testStr != nil else { return false }
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$&*]).{8,}")
        return passwordTest.evaluate(with: testStr)
    }
    
    //MARK: Alert Function
    class public func ShowAlert(vc: UIViewController, title: String, message: String ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        vc.present(alert, animated: true, completion: nil)
    }
}

extension String {
    //This function trim only white space:
    func trim() -> String {
        return self.trimmingCharacters(in: CharacterSet.whitespaces)
    }
    //This function trim whitespeaces and new line that you enter:
    func trimWhiteSpaceAndNewLine() -> String {
        return self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    }
}

class Storyboard {
    static let controller = ViewController()
    
    
}

extension Storyboard {
    struct ViewController {
        private let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        func sideView() -> SideMenuVC {
            return mainStoryboard.instantiateViewController(withIdentifier: "SideMenuVC") as! SideMenuVC
        }
    }
}


extension UIImage{
    func resizeWithWidth(width: CGFloat) -> UIImage? {
        let imageView = UIImageView(frame: CGRect(origin: .zero, size: CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))))
        imageView.contentMode = .scaleAspectFit
        imageView.image = self
        UIGraphicsBeginImageContextWithOptions(imageView.bounds.size, false, scale)
        guard let context = UIGraphicsGetCurrentContext() else { return nil }
        imageView.layer.render(in: context)
        guard let result = UIGraphicsGetImageFromCurrentImageContext() else { return nil }
        UIGraphicsEndImageContext()
        return result
    }
}

extension UIImage {
    func resized(withPercentage percentage: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: size.width * percentage, height: size.height * percentage)
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
    func resized(toWidth width: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: width, height: CGFloat(ceil(width/size.width * size.height)))
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}

extension UIImage {
//    var jpeg: Data? {
//        return UIImageJPEGRepresentation(self, 1)   // QUALITY min = 0 / max = 1
//
//     //  return self.jpegData()
//    }
    var png: Data? {
        return self.pngData()
    }
}
